package com.fluper.seeway.onBoard.model

class NotificationModel (val title: String,val time : String)