package com.fluper.seeway.onBoard.model

data class UserTypeModel(val name: String, var img: Int)

