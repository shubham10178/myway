package com.fluper.seeway.panels.passenger.ui.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.fluper.seeway.R

class DriverDetailsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_driver_details)
    }
}