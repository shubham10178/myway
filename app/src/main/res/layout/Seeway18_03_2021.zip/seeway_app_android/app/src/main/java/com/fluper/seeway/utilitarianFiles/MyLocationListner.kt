package com.fluper.seeway.utilitarianFiles

interface MyLocationListener{
    fun onLocationUpdate(lat:Double,long:Double)
}