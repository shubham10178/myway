package com.fluper.seeway.database.beans

data class MessageResponse(
    val message: String? = "" // logout successfully
)