package com.fluper.seeway.utilitarianFiles

object IntentConstant {

    const val REQ_WHERE_TO=1


}