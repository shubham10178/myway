package com.fluper.seeway.panels.chat.ui.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.fluper.seeway.R

class ChatActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)
    }
}