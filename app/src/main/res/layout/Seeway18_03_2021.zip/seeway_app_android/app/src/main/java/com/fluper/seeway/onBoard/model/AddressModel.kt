package com.fluper.seeway.onBoard.model

class AddressModel(val title: String,val address : String, var img: Int)
