package com.fluper.seeway.panels.passenger.viewmodel

import com.fluper.seeway.base.BaseViewModel




class LocationsViewModel :BaseViewModel(){


}