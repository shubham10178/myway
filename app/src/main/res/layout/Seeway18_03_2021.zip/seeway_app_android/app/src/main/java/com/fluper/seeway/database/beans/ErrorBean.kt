package com.fluper.seeway.database.beans

data class ErrorBean(
    val message: String,
    val error: String
)